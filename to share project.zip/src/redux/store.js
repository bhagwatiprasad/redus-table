import { configureStore } from "@reduxjs/toolkit";
import tableReducer from './tableSlice'
import counterReducer from './counterSlice'


export const store = configureStore({
  reducer: {
    // counter: counterReducer,
    table: tableReducer
  },
})