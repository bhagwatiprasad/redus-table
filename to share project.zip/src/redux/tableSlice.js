import { createSlice } from '@reduxjs/toolkit'


// create a slice
export const tableSlice = createSlice({
  name: "table",
  initialState: {data : []},
  reducers:  {
    createEntry: (state, action) => {
      state.data.push(action.payload)
    },
    updateEntry: (state, action) => {
      let row = state.data.find((row) => action.payload.rowId == row.rowId)
      row.name = action.payload.content.name
      row.dob = action.payload.content.dob
      row.email = action.payload.content.email
    },
    deleteEntry: (state, action) => {
      let row = state.data.find((row) => action.payload.rowId == row.rowId);
      // [].unsh
    },
  },
});

export const { createEntry, updateEntry, deleteEntry  } = tableSlice.actions;

export default tableSlice.reducer