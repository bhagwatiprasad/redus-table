import logo from "./logo.svg";
import "./App.css";
import FormCmp from "./components/FormCmp.jsx";
import { Provider } from "react-redux";
import store from "./redux/store.js";

function App() {
  return (
    // <Provider store={store}>
      <div className="App">
        <FormCmp />
      </div>
    // </Provider>
  );
}

export default App;
