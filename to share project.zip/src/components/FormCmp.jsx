import React, { useEffect, useState } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { createEntry, updateEntry, deleteEntry } from '../redux/tableSlice'

const FormCmp = ({rowId, isAdd=true}) => {
  const table = useSelector((state) => state.table.data)
  console.log('table', table)
  let row = table.find((item) => item.rowId == rowId)
  // if (row !== undefined || row != null){
  //   row = {na}
  // }
  let [rowState, setRowState] =  useState({...row});
  const dispatch = useDispatch()

  const handleChange = (e) => {
    console.log('e.target.name : ', e.target.name , e.target.value);
    if (e.target.name == 'name'){
      setRowState((row) => ({...row, name: e.target.value}))
    } else if (e.target.name == 'email'){
      setRowState((row) => ({...row, email: e.target.value}))
    } else {
      setRowState((row) => ({...row, dob: e.target.value}))
    }
    // setRowState((row) => ({...row , [e.e.target.name]: e.target.value}))
  }

  useEffect(() => {
    console.log("rowState : ", rowState);
  })

  return (
    <div>
      <form style={{}}>
        <input type="text" name="name" id="name" value={rowState?.name | ""} onChange={handleChange} />
        <input type="email" name="email" id="email" value={rowState?.email | ""} onChange={handleChange}/>
        <input type="date" name="dob" id="dob" value={rowState?.date | "2022-11-02"} onChange={handleChange}/>
        <button onClick={(e) => isAdd? dispatch(createEntry(rowState)) : dispatch(updateEntry({rowId , rowState}))} > {isAdd ? `Submit` : `Update`}</button>
      </form>
    </div>
  )
}

export default FormCmp
